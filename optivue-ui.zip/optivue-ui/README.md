# Optivue — SEO Intelligence Dashboard

A React + Vite implementation inspired by the supplied ScoutSEO reference UI, adapted for the Optivue competitor research / SEO intelligence product.

## Run

```bash
npm install
npm run dev
```

Then open the local Vite URL.

## Included

- Responsive dashboard shell and sidebar
- Project header + analysis controls
- Overview / SEO Audit / Competitors / Content Gaps / Keywords / AI Insights / Recommendations / Reports tabs
- SEO score rings
- Competitor score comparison chart
- Content opportunity cards and priority badges
- Recent activity feed
- Recommended next steps
- Add Website modal
- Re-analyze loading state
- Toast feedback for UI actions
- Responsive mobile layout

## Next implementation phase

Connect the UI to the Optivue backend: crawler, SEO audit engine, competitor discovery, keyword data, content-gap calculations, AI summaries, reports, authentication, and persistent project data.
