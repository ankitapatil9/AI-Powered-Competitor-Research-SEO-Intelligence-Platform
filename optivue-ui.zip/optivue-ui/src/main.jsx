import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, AlertTriangle, ArrowRight, BarChart3, Bell, Bot, CalendarDays,
  Check, CheckCircle2, ChevronDown, ChevronLeft, CircleHelp, FileText,
  Globe2, KeyRound, Lightbulb, Menu, Plus, RefreshCw, Search, Settings,
  Sparkles, Target, Users, X, Zap
} from 'lucide-react';
import './styles.css';

const nav = [
  ['Dashboard', BarChart3], ['Projects', FileText], ['Websites', Globe2],
  ['Competitors', Users], ['SEO Audit', Search], ['Content Gaps', Target],
  ['Keywords', KeyRound], ['AI Insights', Sparkles], ['Recommendations', Lightbulb],
  ['Reports', FileText]
];
const tabs = ['Overview', 'SEO Audit', 'Competitors', 'Content Gaps', 'Keywords', 'AI Insights', 'Recommendations', 'Reports'];
const gaps = [
  ['EV Battery Maintenance', '3', '0', 'High'],
  ['EV Charging Cost', '4', '0', 'High'],
  ['EV Battery Life', '3', 'Partial', 'Medium'],
  ['EV Charging Guide', '2', '0', 'Medium'],
  ['Electric Vehicle Tax', '3', '0', 'Low']
];
const activity = [
  ['Crawling completed', 'example.com · 42 pages', '2h ago', CheckCircle2],
  ['Competitor analysis completed', '3 competitors analyzed', '2h ago', BarChart3],
  ['AI insights generated', '27 opportunities found', '3h ago', Sparkles],
  ['Report generated', 'EV Website SEO Research.pdf', '3h ago', FileText]
];

function Icon({ name }) {
  const C = { search: Search, bell: Bell, menu: Menu }[name] || Sparkles;
  return <C size={18} strokeWidth={1.8} />;
}

function ScoreRing({ score }) {
  const radius = 37, circumference = 2 * Math.PI * radius;
  const dash = circumference * (score / 100);
  return <div className="score-ring">
    <svg viewBox="0 0 96 96">
      <circle className="ring-bg" cx="48" cy="48" r={radius} />
      <circle className="ring-value" cx="48" cy="48" r={radius} strokeDasharray={`${dash} ${circumference}`} />
    </svg>
    <div className="score-text"><b>{score}</b><span>/100</span></div>
  </div>
}

function MetricCard({ icon: I, title, subtitle, score, stats }) {
  return <section className="card metric-card">
    <div className="card-title"><span className="icon-box"><I size={18}/></span><div><h3>{title}</h3><p>{subtitle}</p></div></div>
    <div className="metric-body"><ScoreRing score={score}/><div className="stats">{stats.map(([n,l,c]) => <div key={l}><strong className={c}>{n}</strong><span>{l}</span></div>)}</div></div>
  </section>
}

function ComparisonChart() {
  const data = [72,84,78,69];
  const labels = ['Your Site','Competitor A','Competitor B','Competitor C'];
  return <section className="card chart-card">
    <div className="section-head"><div><h3><BarChart3 size={18}/> SEO Score Comparison</h3></div><button className="link-btn">View Details <ArrowRight size={14}/></button></div>
    <div className="chart">
      <div className="y-axis"><span>100</span><span>80</span><span>60</span><span>40</span><span>20</span><span>0</span></div>
      <div className="bars">{data.map((v,i)=><div className="bar-wrap" key={labels[i]}><strong>{v}</strong><div className="bar" style={{height:`${v*1.25}px`}}></div><span>{labels[i]}</span></div>)}</div>
      <div className="grid-lines"><i/><i/><i/><i/><i/></div>
    </div>
  </section>
}

function App() {
  const [active, setActive] = useState('Overview');
  const [project, setProject] = useState('EV Website SEO Research');
  const [modal, setModal] = useState(false);
  const [website, setWebsite] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [toast, setToast] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const notify = (msg) => { setToast(msg); setTimeout(()=>setToast(''), 2500); };
  const reanalyze = () => { setAnalyzing(true); setTimeout(()=>{setAnalyzing(false); notify('Analysis refreshed successfully');}, 1400); };
  const addWebsite = () => { if (!website.trim()) return; setModal(false); notify(`${website.trim()} added to project`); setWebsite(''); };
  const content = useMemo(() => active === 'Overview' ? null : `The ${active} workspace is ready for live SEO intelligence data.`, [active]);

  return <div className="app">
    <aside className={`sidebar ${sidebarOpen?'open':''}`}>
      <div className="brand"><div className="brand-mark">◆</div><div><b>Optivue</b><span>Find Gaps. Create Opportunities.</span></div></div>
      <nav>{nav.map(([label,I]) => <button key={label} className={label==='Projects'?'active':''} onClick={()=>notify(`${label} selected`)}><I size={18}/><span>{label}</span></button>)}</nav>
      <div className="sidebar-bottom">
        <button><Settings size={18}/>Settings</button><button><CircleHelp size={18}/>Help & Support</button>
        <div className="plan"><div className="plan-title"><span>♛ Pro Plan</span></div><p>You have used <b>12 / 50</b> analyses</p><div className="progress"><i/></div><button onClick={()=>notify('Upgrade flow opened')}>Upgrade Plan</button></div>
      </div>
    </aside>
    <main>
      <header className="topbar">
        <button className="mobile-menu" onClick={()=>setSidebarOpen(!sidebarOpen)}><Menu/></button>
        <div className="breadcrumbs"><ChevronLeft size={18}/><span>Projects</span><b>›</b><strong>{project}</strong></div>
        <div className="top-actions"><button><Icon name="search"/></button><button className="notif"><Icon name="bell"/><i/></button><div className="avatar">AP</div><span className="user-name">Ankita Patil</span><ChevronDown size={14}/></div>
      </header>
      <div className="content">
        <div className="project-head">
          <div className="project-title"><div className="project-icon"><Sparkles/></div><div><div className="title-row"><h1>{project}</h1><button onClick={()=>notify('Project rename opened')}><FileText size={15}/></button></div><p>Analyze. Compare. Discover Opportunities.</p></div></div>
          <div className="project-actions"><div className="last"><CalendarDays size={17}/><span>Last analyzed<br/><b>Sep 20, 2026, 10:30 AM</b></span></div><button className="outline" onClick={reanalyze}><RefreshCw size={16} className={analyzing?'spin':''}/>{analyzing?'Analyzing...':'Re-analyze'}</button><button className="primary" onClick={()=>setModal(true)}><Plus size={17}/>Add Website</button></div>
        </div>
        <div className="tabs">{tabs.map(t=><button key={t} className={active===t?'selected':''} onClick={()=>setActive(t)}>{t}</button>)}</div>
        {content ? <section className="placeholder card"><Sparkles size={30}/><h2>{active}</h2><p>{content}</p><button className="primary" onClick={()=>setActive('Overview')}>Back to Overview</button></section> : <>
        <section className="hero">
          <div className="hero-copy"><div className="eyebrow"><Sparkles size={16}/> AI-POWERED SEO INTELLIGENCE</div><h2>Turn Competitor Research<br/>into Growth Opportunities</h2><p>We analyze your website and competitors to find SEO gaps,<br/>keyword opportunities, and content ideas that actually work.</p><div className="hero-buttons"><button className="primary" onClick={()=>notify('AI Summary opened')}>View AI Summary <ArrowRight size={16}/></button><button className="outline" onClick={()=>notify('Report download prepared')}><FileText size={16}/>Download Report</button></div></div>
          <div className="hero-art"><div className="pill orange">Content Gaps</div><div className="pill blue">Keyword Opportunities</div><div className="site-box"><Sparkles size={28}/><span>Your Website</span></div><div className="mini competitor a"><span></span><span></span><b>Competitor A</b></div><div className="mini competitor b"><span></span><span></span><b>Competitor B</b></div><div className="pill green bottom">SEO Analysis</div><div className="pill purple bottom2">AI Insights</div><div className="arrow ar1">↗</div><div className="arrow ar2">↖</div></div>
        </section>
        <div className="metric-grid"><MetricCard icon={Globe2} title="Your Website" subtitle="example.com" score={72} stats={[[42,'Pages',''],[6,'Critical Issues','red'],[18,'Warnings','orange'],[32,'Passed','green']]}/><MetricCard icon={Users} title="Competitors (3)" subtitle="Avg. Score" score={77} stats={[[203,'Total Pages',''],[21,'Critical Issues','red'],[38,'Warnings','orange'],[144,'Passed','green']]}/><section className="card opportunity"><div className="card-title"><span className="icon-box bulb"><Lightbulb size={18}/></span><div><h3>Content Opportunities</h3></div><button className="link-btn" onClick={()=>setActive('Content Gaps')}>View All <ArrowRight size={14}/></button></div><div className="opp-body"><b>18</b><span>Content Gaps</span><div className="priority"><p><i className="dot red"></i>8 <span>High Priority</span></p><p><i className="dot orange"></i>7 <span>Medium Priority</span></p><p><i className="dot green"></i>3 <span>Low Priority</span></p></div></div></section></div>
        <div className="lower-grid"><ComparisonChart/><section className="card gaps-card"><div className="section-head"><h3><FileText size={18}/> Top Content Gaps</h3><button className="link-btn" onClick={()=>setActive('Content Gaps')}>View All <ArrowRight size={14}/></button></div><table><thead><tr><th>Topic</th><th>Competitors</th><th>Your Site</th><th>Priority</th></tr></thead><tbody>{gaps.map(g=><tr key={g[0]}><td>{g[0]}</td><td>{g[1]}</td><td>{g[2]}</td><td><span className={`badge ${g[3].toLowerCase()}`}>{g[3]}</span></td></tr>)}</tbody></table></section><section className="card activity"><div className="section-head"><h3><Activity size={18}/> Recent Activity</h3><button className="link-btn">View All <ArrowRight size={14}/></button></div>{activity.map(([t,s,time,I])=><div className="activity-row" key={t}><span className="activity-icon"><I size={15}/></span><div><b>{t}</b><span>{s}</span></div><time>{time}</time></div>)}</section></div>
        <section className="card next-steps"><div className="next-head"><h3><span className="check-square"><Check size={15}/></span> Recommended Next Steps</h3><button className="primary" onClick={()=>setActive('Recommendations')}>View Recommendations <ArrowRight size={16}/></button></div><div className="steps">{[['1','Review AI Summary','Get key insights and opportunities'],['2','Check Content Gaps','See topics to target'],['3','Implement Recommendations','Take action on high priority items'],['4','Track Progress','Re-analyze after changes']].map((s,i)=><React.Fragment key={s[0]}><div className="step"><span>{s[0]}</span><div><b>{s[1]}</b><small>{s[2]}</small></div></div>{i<3&&<ArrowRight className="step-arrow" size={20}/>}</React.Fragment>)}</div></section>
        </>}
      </div>
    </main>
    {modal && <div className="modal-backdrop" onClick={()=>setModal(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setModal(false)}><X/></button><div className="modal-icon"><Globe2/></div><h2>Add Website</h2><p>Add a website to crawl and compare inside this project.</p><label>Website URL<input autoFocus value={website} onChange={e=>setWebsite(e.target.value)} placeholder="https://example.com" onKeyDown={e=>e.key==='Enter'&&addWebsite()}/></label><div className="modal-actions"><button className="outline" onClick={()=>setModal(false)}>Cancel</button><button className="primary" onClick={addWebsite}>Add Website <ArrowRight size={16}/></button></div></div></div>}
    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>
}

createRoot(document.getElementById('root')).render(<App />);
